export default {
  _widgetLabel: 'Search Custom',
  showResult: 'Show search results for {searchText}',
  hideResult: 'Hide search results for {searchText}',
  allSearchSources: 'All search sources',
  noResult: 'No results found for "{searchText}"',
  couldNotRetrieve: 'Could not retrieve current location.',
  showMoreResult: 'Show more results',
  clearAllHistories: 'Clear all histories',
  clearHistory: 'Clear history',
  clearThisHistories: 'Remove this history',
  clearRecentSearches: 'Recent searches',
  searchIn: 'Search in {value}',
  searchResults: 'Search result'
}
